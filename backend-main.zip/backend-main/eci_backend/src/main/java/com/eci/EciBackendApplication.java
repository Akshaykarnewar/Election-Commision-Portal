package com.eci;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EciBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(EciBackendApplication.class, args);
	}

}
